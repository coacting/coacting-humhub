-- phpMyAdmin SQL Dump
-- version 4.7.5
-- https://www.phpmyadmin.net/
--
-- Host: mysql:3306
-- Generation Time: May 20, 2020 at 11:02 PM
-- Server version: 5.7.20
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `coacting_hh`
--

-- --------------------------------------------------------

--
-- Table structure for table `activity`
--

CREATE TABLE `activity` (
  `id` int(11) NOT NULL,
  `class` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `object_model` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `object_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `activity`
--

INSERT INTO `activity` (`id`, `class`, `module`, `object_model`, `object_id`) VALUES
(1, 'humhub\\modules\\space\\activities\\Created', 'space', 'humhub\\modules\\space\\models\\Space', 1),
(2, 'humhub\\modules\\content\\activities\\ContentCreated', 'content', 'humhub\\modules\\post\\models\\Post', 1),
(3, 'humhub\\modules\\space\\activities\\MemberAdded', 'space', 'humhub\\modules\\space\\models\\Space', 1),
(4, 'humhub\\modules\\space\\activities\\MemberAdded', 'space', 'humhub\\modules\\space\\models\\Space', 1),
(5, 'humhub\\modules\\content\\activities\\ContentCreated', 'content', 'humhub\\modules\\post\\models\\Post', 2),
(6, 'humhub\\modules\\comment\\activities\\NewComment', 'comment', 'humhub\\modules\\comment\\models\\Comment', 1),
(7, 'humhub\\modules\\comment\\activities\\NewComment', 'comment', 'humhub\\modules\\comment\\models\\Comment', 2),
(8, 'humhub\\modules\\like\\activities\\Liked', 'like', 'humhub\\modules\\like\\models\\Like', 1),
(9, 'humhub\\modules\\like\\activities\\Liked', 'like', 'humhub\\modules\\like\\models\\Like', 2);

-- --------------------------------------------------------

--
-- Table structure for table `comment`
--

CREATE TABLE `comment` (
  `id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci,
  `object_model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `comment`
--

INSERT INTO `comment` (`id`, `message`, `object_model`, `object_id`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 'Nike – Just buy it. ;Wink;', 'humhub\\modules\\post\\models\\Post', 2, '2020-05-20 22:47:22', 2, '2020-05-20 22:47:22', 2),
(2, 'Calvin Klein – Between love and madness lies obsession.', 'humhub\\modules\\post\\models\\Post', 2, '2020-05-20 22:47:22', 3, '2020-05-20 22:47:22', 3);

-- --------------------------------------------------------

--
-- Table structure for table `content`
--

CREATE TABLE `content` (
  `id` int(11) NOT NULL,
  `guid` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int(11) NOT NULL,
  `visibility` tinyint(4) DEFAULT NULL,
  `pinned` tinyint(4) DEFAULT NULL,
  `archived` tinytext COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `contentcontainer_id` int(11) DEFAULT NULL,
  `stream_sort_date` datetime DEFAULT NULL,
  `stream_channel` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `content`
--

INSERT INTO `content` (`id`, `guid`, `object_model`, `object_id`, `visibility`, `pinned`, `archived`, `created_at`, `created_by`, `updated_at`, `updated_by`, `contentcontainer_id`, `stream_sort_date`, `stream_channel`) VALUES
(1, 'ca01d563-db91-4e1a-a55c-0eeba2510384', 'humhub\\modules\\activity\\models\\Activity', 1, 1, 0, '0', '2020-05-20 22:47:19', 1, '2020-05-20 22:47:19', 1, 2, '2020-05-20 22:47:19', 'activity'),
(2, '5476a97b-91a3-46d9-9533-73cb335900dc', 'humhub\\modules\\post\\models\\Post', 1, 1, 0, '0', '2020-05-20 22:47:19', 1, '2020-05-20 22:47:19', 1, 2, '2020-05-20 22:47:19', 'default'),
(3, 'ad5c10a1-8c5a-42c1-9250-685ebc065c53', 'humhub\\modules\\activity\\models\\Activity', 2, 1, 0, '0', '2020-05-20 22:47:19', 1, '2020-05-20 22:47:19', 1, 2, '2020-05-20 22:47:19', 'activity'),
(4, 'f145a9de-b50b-48c8-b606-bacda6bb0b04', 'humhub\\modules\\activity\\models\\Activity', 3, 0, 0, '0', '2020-05-20 22:47:22', 2, '2020-05-20 22:47:22', 1, 2, '2020-05-20 22:47:22', 'activity'),
(5, '86ea11f2-25c9-4cbc-9d19-dd48472ffff8', 'humhub\\modules\\activity\\models\\Activity', 4, 0, 0, '0', '2020-05-20 22:47:22', 3, '2020-05-20 22:47:22', 1, 2, '2020-05-20 22:47:22', 'activity'),
(6, '0e0d5cb2-0d64-4624-b9cc-2bd0c38f9aca', 'humhub\\modules\\post\\models\\Post', 2, 0, 0, '0', '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1, 2, '2020-05-20 22:47:22', 'default'),
(7, '25a8a08c-d610-4b4f-a3a9-c240fe764698', 'humhub\\modules\\activity\\models\\Activity', 5, 0, 0, '0', '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1, 2, '2020-05-20 22:47:22', 'activity'),
(8, '25a19642-30af-4642-b470-ecc16e3dfd2d', 'humhub\\modules\\activity\\models\\Activity', 6, 0, 0, '0', '2020-05-20 22:47:22', 2, '2020-05-20 22:47:22', 2, 2, '2020-05-20 22:47:22', 'activity'),
(9, '20ea1abc-7cad-490b-9947-f9c325220d01', 'humhub\\modules\\activity\\models\\Activity', 7, 0, 0, '0', '2020-05-20 22:47:22', 3, '2020-05-20 22:47:22', 3, 2, '2020-05-20 22:47:22', 'activity'),
(10, 'ab6513d7-8c93-48fb-ad1e-6f4c402ffebd', 'humhub\\modules\\activity\\models\\Activity', 8, 0, 0, '0', '2020-05-20 22:47:23', 3, '2020-05-20 22:47:23', 3, 2, '2020-05-20 22:47:23', 'activity'),
(11, '4056e0b8-9ba1-4a6d-b225-4934cbe88151', 'humhub\\modules\\activity\\models\\Activity', 9, 0, 0, '0', '2020-05-20 22:47:23', 3, '2020-05-20 22:47:23', 3, 2, '2020-05-20 22:47:23', 'activity');

-- --------------------------------------------------------

--
-- Table structure for table `contentcontainer`
--

CREATE TABLE `contentcontainer` (
  `id` int(11) NOT NULL,
  `guid` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` char(60) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pk` int(11) DEFAULT NULL,
  `owner_user_id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `contentcontainer`
--

INSERT INTO `contentcontainer` (`id`, `guid`, `class`, `pk`, `owner_user_id`) VALUES
(1, 'a7638a08-35c3-47a6-bb76-d68738799a2f', 'humhub\\modules\\user\\models\\User', 1, 1),
(2, '8f4545a9-fdf8-4a80-841d-7ae150820de4', 'humhub\\modules\\space\\models\\Space', 1, 1),
(3, '0a6c2ff1-aa0d-4e04-b98e-e086b454d5c8', 'humhub\\modules\\user\\models\\User', 2, 2),
(4, '16daae3f-fa9b-4be6-b4f9-17efae15804d', 'humhub\\modules\\user\\models\\User', 3, 3);

-- --------------------------------------------------------

--
-- Table structure for table `contentcontainer_module`
--

CREATE TABLE `contentcontainer_module` (
  `contentcontainer_id` int(11) NOT NULL,
  `module_id` char(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_state` smallint(6) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contentcontainer_permission`
--

CREATE TABLE `contentcontainer_permission` (
  `permission_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contentcontainer_id` int(11) NOT NULL,
  `group_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `contentcontainer_setting`
--

CREATE TABLE `contentcontainer_setting` (
  `id` int(11) NOT NULL,
  `module_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contentcontainer_id` int(11) NOT NULL,
  `name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content_tag`
--

CREATE TABLE `content_tag` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `module_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `contentcontainer_id` int(11) DEFAULT NULL,
  `type` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sort_order` int(11) DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `content_tag_relation`
--

CREATE TABLE `content_tag_relation` (
  `id` int(11) NOT NULL,
  `content_id` int(11) NOT NULL,
  `tag_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `file`
--

CREATE TABLE `file` (
  `id` int(11) NOT NULL,
  `guid` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `object_model` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `object_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `file_name` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mime_type` varchar(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `size` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `show_in_stream` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group`
--

CREATE TABLE `group` (
  `id` int(11) NOT NULL,
  `space_id` int(10) DEFAULT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ldap_dn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_admin_group` tinyint(1) NOT NULL DEFAULT '0',
  `show_at_registration` tinyint(1) NOT NULL DEFAULT '1',
  `show_at_directory` tinyint(1) NOT NULL DEFAULT '1',
  `sort_order` int(11) NOT NULL DEFAULT '100'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `group`
--

INSERT INTO `group` (`id`, `space_id`, `name`, `description`, `created_at`, `created_by`, `updated_at`, `updated_by`, `ldap_dn`, `is_admin_group`, `show_at_registration`, `show_at_directory`, `sort_order`) VALUES
(1, NULL, 'Administrator', 'Administrator Group', '2020-05-20 22:46:17', NULL, NULL, NULL, NULL, 1, 0, 0, 100),
(2, NULL, 'Users', 'Example Group by Installer', '2020-05-20 22:46:25', NULL, '2020-05-20 22:46:25', NULL, NULL, 0, 1, 0, 100);

-- --------------------------------------------------------

--
-- Table structure for table `group_permission`
--

CREATE TABLE `group_permission` (
  `permission_id` varchar(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `group_id` int(11) NOT NULL,
  `module_id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `class` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` tinyint(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `group_user`
--

CREATE TABLE `group_user` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `group_id` int(11) NOT NULL,
  `is_group_manager` tinyint(1) NOT NULL DEFAULT '0',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `group_user`
--

INSERT INTO `group_user` (`id`, `user_id`, `group_id`, `is_group_manager`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, 1, 1, 0, '2020-05-20 22:47:18', NULL, '2020-05-20 22:47:18', NULL),
(2, 2, 2, 0, '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1),
(3, 3, 2, 0, '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `like`
--

CREATE TABLE `like` (
  `id` int(11) NOT NULL,
  `target_user_id` int(11) DEFAULT NULL,
  `object_model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int(11) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `like`
--

INSERT INTO `like` (`id`, `target_user_id`, `object_model`, `object_id`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, NULL, 'humhub\\modules\\comment\\models\\Comment', 1, '2020-05-20 22:47:22', 3, '2020-05-20 22:47:22', 3),
(2, NULL, 'humhub\\modules\\post\\models\\Post', 2, '2020-05-20 22:47:23', 3, '2020-05-20 22:47:23', 3);

-- --------------------------------------------------------

--
-- Table structure for table `live`
--

CREATE TABLE `live` (
  `id` int(11) NOT NULL,
  `contentcontainer_id` int(11) DEFAULT NULL,
  `visibility` int(1) DEFAULT NULL,
  `serialized_data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `live`
--

INSERT INTO `live` (`id`, `contentcontainer_id`, `visibility`, `serialized_data`, `created_at`) VALUES
(1, 2, 1, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:1;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"a7638a08-35c3-47a6-bb76-d68738799a2f\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:1;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:1;}', 1590014839),
(2, 2, 1, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:3;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"a7638a08-35c3-47a6-bb76-d68738799a2f\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:2;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:1;}', 1590014839),
(3, 2, 1, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:2;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"a7638a08-35c3-47a6-bb76-d68738799a2f\";s:11:\"sourceClass\";s:31:\"humhub\\modules\\post\\models\\Post\";s:8:\"sourceId\";i:1;s:6:\"silent\";b:0;s:13:\"streamChannel\";s:7:\"default\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:1;}', 1590014839),
(4, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:4;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"0a6c2ff1-aa0d-4e04-b98e-e086b454d5c8\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:3;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014842),
(5, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:5;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"16daae3f-fa9b-4be6-b4f9-17efae15804d\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:4;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014842),
(6, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:7;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"a7638a08-35c3-47a6-bb76-d68738799a2f\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:5;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014842),
(7, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:6;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"a7638a08-35c3-47a6-bb76-d68738799a2f\";s:11:\"sourceClass\";s:31:\"humhub\\modules\\post\\models\\Post\";s:8:\"sourceId\";i:2;s:6:\"silent\";b:0;s:13:\"streamChannel\";s:7:\"default\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014842),
(8, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:8;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"0a6c2ff1-aa0d-4e04-b98e-e086b454d5c8\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:6;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014842),
(9, 1, 0, 'O:38:\"humhub\\modules\\comment\\live\\NewComment\":4:{s:9:\"commentId\";i:1;s:9:\"contentId\";i:6;s:18:\"contentContainerId\";i:1;s:10:\"visibility\";i:0;}', 1590014842),
(10, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:9;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"16daae3f-fa9b-4be6-b4f9-17efae15804d\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:7;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014842),
(11, 1, 0, 'O:38:\"humhub\\modules\\comment\\live\\NewComment\":4:{s:9:\"commentId\";i:2;s:9:\"contentId\";i:6;s:18:\"contentContainerId\";i:1;s:10:\"visibility\";i:0;}', 1590014842),
(12, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:10;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"16daae3f-fa9b-4be6-b4f9-17efae15804d\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:8;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014842),
(13, 2, 0, 'O:38:\"humhub\\modules\\content\\live\\NewContent\":11:{s:9:\"contentId\";i:11;s:5:\"sguid\";s:36:\"8f4545a9-fdf8-4a80-841d-7ae150820de4\";s:5:\"uguid\";N;s:10:\"originator\";s:36:\"16daae3f-fa9b-4be6-b4f9-17efae15804d\";s:11:\"sourceClass\";s:39:\"humhub\\modules\\activity\\models\\Activity\";s:8:\"sourceId\";i:9;s:6:\"silent\";b:1;s:13:\"streamChannel\";s:8:\"activity\";s:6:\"insert\";b:1;s:18:\"contentContainerId\";i:2;s:10:\"visibility\";i:0;}', 1590014843),
(14, 1, 2, 'O:48:\"humhub\\modules\\notification\\live\\NewNotification\":6:{s:14:\"notificationId\";i:1;s:17:\"notificationGroup\";s:81:\"humhub\\modules\\comment\\notifications\\NewComment:humhub\\modules\\post\\models\\Post-2\";s:4:\"text\";s:95:\"David Roberts commented post \"We&#039;re looking for great slogans of famous brands. Maybe...\".\";s:2:\"ts\";i:1590014843;s:18:\"contentContainerId\";i:1;s:10:\"visibility\";i:2;}', 1590014843),
(15, 4, 2, 'O:48:\"humhub\\modules\\notification\\live\\NewNotification\":6:{s:14:\"notificationId\";i:2;s:17:\"notificationGroup\";s:81:\"humhub\\modules\\comment\\notifications\\NewComment:humhub\\modules\\post\\models\\Post-2\";s:4:\"text\";s:95:\"David Roberts commented post \"We&#039;re looking for great slogans of famous brands. Maybe...\".\";s:2:\"ts\";i:1590014843;s:18:\"contentContainerId\";i:4;s:10:\"visibility\";i:2;}', 1590014843),
(16, 1, 2, 'O:48:\"humhub\\modules\\notification\\live\\NewNotification\":6:{s:14:\"notificationId\";i:3;s:17:\"notificationGroup\";s:81:\"humhub\\modules\\comment\\notifications\\NewComment:humhub\\modules\\post\\models\\Post-2\";s:4:\"text\";s:95:\"Sara Schuster commented post \"We&#039;re looking for great slogans of famous brands. Maybe...\".\";s:2:\"ts\";i:1590014843;s:18:\"contentContainerId\";i:1;s:10:\"visibility\";i:2;}', 1590014843),
(17, 3, 2, 'O:48:\"humhub\\modules\\notification\\live\\NewNotification\":6:{s:14:\"notificationId\";i:4;s:17:\"notificationGroup\";s:81:\"humhub\\modules\\comment\\notifications\\NewComment:humhub\\modules\\post\\models\\Post-2\";s:4:\"text\";s:95:\"Sara Schuster commented post \"We&#039;re looking for great slogans of famous brands. Maybe...\".\";s:2:\"ts\";i:1590014843;s:18:\"contentContainerId\";i:3;s:10:\"visibility\";i:2;}', 1590014843),
(18, 3, 2, 'O:48:\"humhub\\modules\\notification\\live\\NewNotification\":6:{s:14:\"notificationId\";i:5;s:17:\"notificationGroup\";s:81:\"humhub\\modules\\like\\notifications\\NewLike:humhub\\modules\\comment\\models\\Comment-1\";s:4:\"text\";s:57:\"Sara Schuster likes comment \"Nike – Just buy it. 😉\".\";s:2:\"ts\";i:1590014844;s:18:\"contentContainerId\";i:3;s:10:\"visibility\";i:2;}', 1590014844),
(19, 1, 2, 'O:48:\"humhub\\modules\\notification\\live\\NewNotification\":6:{s:14:\"notificationId\";i:6;s:17:\"notificationGroup\";s:75:\"humhub\\modules\\like\\notifications\\NewLike:humhub\\modules\\post\\models\\Post-2\";s:4:\"text\";s:91:\"Sara Schuster likes post \"We&#039;re looking for great slogans of famous brands. Maybe...\".\";s:2:\"ts\";i:1590014844;s:18:\"contentContainerId\";i:1;s:10:\"visibility\";i:2;}', 1590014844);

-- --------------------------------------------------------

--
-- Table structure for table `log`
--

CREATE TABLE `log` (
  `id` bigint(20) NOT NULL,
  `level` int(11) DEFAULT NULL,
  `category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `log_time` double DEFAULT NULL,
  `prefix` mediumtext COLLATE utf8mb4_unicode_ci,
  `message` mediumtext COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `log`
--

INSERT INTO `log` (`id`, `level`, `category`, `log_time`, `prefix`, `message`) VALUES
(1, 1, 'yii\\base\\ErrorException:32', 1590014786.4333, '[172.18.0.1][-][-]', 'yii\\base\\ErrorException: Module \'memcached\' already loaded in Unknown:0\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(2, 4, 'application', 1590014786.3523, '[172.18.0.1][-][-]', '$_GET = [\n    \'r\' => \'web/pwa-manifest/index\'\n]\n\n$_SERVER = [\n    \'SCRIPT_URL\' => \'/coacting-humhub/index.php\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/index.php\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_ACCEPT\' => \'*/*\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'cors\'\n    \'HTTP_SEC_FETCH_DEST\' => \'empty\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/index.php?r=installer%2Fconfig%2Fbasic\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'33582\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'GET\'\n    \'QUERY_STRING\' => \'r=web%2Fpwa-manifest%2Findex\'\n    \'REQUEST_URI\' => \'/coacting-humhub/index.php?r=web%2Fpwa-manifest%2Findex\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590014786.347\n    \'REQUEST_TIME\' => 1590014786\n]'),
(3, 1, 'yii\\base\\ErrorException:32', 1590014799.7716, '[172.18.0.1][-][-]', 'yii\\base\\ErrorException: Module \'memcached\' already loaded in Unknown:0\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(4, 4, 'application', 1590014799.7048, '[172.18.0.1][-][-]', '$_GET = [\n    \'r\' => \'installer/config/basic\'\n]\n\n$_SERVER = [\n    \'SCRIPT_URL\' => \'/coacting-humhub/index.php\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/index.php\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'CONTENT_LENGTH\' => \'137\'\n    \'HTTP_CACHE_CONTROL\' => \'max-age=0\'\n    \'HTTP_UPGRADE_INSECURE_REQUESTS\' => \'1\'\n    \'HTTP_ORIGIN\' => \'http://localhost\'\n    \'CONTENT_TYPE\' => \'application/x-www-form-urlencoded\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_ACCEPT\' => \'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'navigate\'\n    \'HTTP_SEC_FETCH_USER\' => \'?1\'\n    \'HTTP_SEC_FETCH_DEST\' => \'document\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/index.php?r=installer%2Fconfig%2Fbasic\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'HTTP_COOKIE\' => \'has_js=1; _ga=GA1.1.1494242784.1514515536; G_AUTHUSER_H=0; FUSE2.shortcuts=%5B%5D; io=Woa3K79GCWSAJX5lAAAB; _csrf=030eee503681883696abda24067459984c33c77a83dcfc089f9794cd61556790a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22NnkYh61AOEBxYN3KGRS92DSfz3iXlAG1%22%3B%7D; language=bb6ce3163c1f588e67bf425ac15e954b7b2dba33b884af94990c7579c2f94236a%3A2%3A%7Bi%3A0%3Bs%3A8%3A%22language%22%3Bi%3A1%3Bs%3A5%3A%22en-US%22%3B%7D; PHPSESSID=rj4j3stv4m2v93ku3i91ifkib0\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'33592\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'POST\'\n    \'QUERY_STRING\' => \'r=installer%2Fconfig%2Fbasic\'\n    \'REQUEST_URI\' => \'/coacting-humhub/index.php?r=installer%2Fconfig%2Fbasic\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590014799.7\n    \'REQUEST_TIME\' => 1590014799\n]'),
(5, 1, 'yii\\base\\ErrorException:32', 1590014839.624, '[172.18.0.1][-][-]', 'yii\\base\\ErrorException: Module \'memcached\' already loaded in Unknown:0\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(6, 4, 'application', 1590014839.5558, '[172.18.0.1][-][-]', '$_GET = [\n    \'r\' => \'web/pwa-manifest/index\'\n]\n\n$_SERVER = [\n    \'SCRIPT_URL\' => \'/coacting-humhub/index.php\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/index.php\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_ACCEPT\' => \'*/*\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'cors\'\n    \'HTTP_SEC_FETCH_DEST\' => \'empty\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/index.php?r=installer%2Fconfig%2Fsample-data\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'33706\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'GET\'\n    \'QUERY_STRING\' => \'r=web%2Fpwa-manifest%2Findex\'\n    \'REQUEST_URI\' => \'/coacting-humhub/index.php?r=web%2Fpwa-manifest%2Findex\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590014839.551\n    \'REQUEST_TIME\' => 1590014839\n]'),
(7, 1, 'Error', 1590014844.4059, '[172.18.0.1][-][-]', 'Error: Class \'humhub\\modules\\installer\\controllers\\CException\' not found in /var/www/html/coacting-humhub/protected/humhub/modules/installer/controllers/ConfigController.php:520\nStack trace:\n#0 [internal function]: humhub\\modules\\installer\\controllers\\ConfigController->actionFinished()\n#1 /var/www/html/coacting-humhub/protected/vendor/yiisoft/yii2/base/InlineAction.php(57): call_user_func_array(Array, Array)\n#2 /var/www/html/coacting-humhub/protected/vendor/yiisoft/yii2/base/Controller.php(157): yii\\base\\InlineAction->runWithParams(Array)\n#3 /var/www/html/coacting-humhub/protected/vendor/yiisoft/yii2/base/Module.php(528): yii\\base\\Controller->runAction(\'finished\', Array)\n#4 /var/www/html/coacting-humhub/protected/vendor/yiisoft/yii2/web/Application.php(103): yii\\base\\Module->runAction(\'installer/confi...\', Array)\n#5 /var/www/html/coacting-humhub/protected/vendor/yiisoft/yii2/base/Application.php(386): yii\\web\\Application->handleRequest(Object(humhub\\components\\Request))\n#6 /var/www/html/coacting-humhub/index.php(25): yii\\base\\Application->run()\n#7 {main}'),
(8, 4, 'application', 1590014844.359, '[172.18.0.1][-][-]', '$_GET = [\n    \'r\' => \'installer/config/finished\'\n]\n\n$_SERVER = [\n    \'SCRIPT_URL\' => \'/coacting-humhub/index.php\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/index.php\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'HTTP_CACHE_CONTROL\' => \'max-age=0\'\n    \'HTTP_ACCEPT\' => \'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9\'\n    \'HTTP_UPGRADE_INSECURE_REQUESTS\' => \'1\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_DEST\' => \'empty\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/index.php?r=installer%2Fconfig%2Fsample-data\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'HTTP_COOKIE\' => \'has_js=1; _ga=GA1.1.1494242784.1514515536; G_AUTHUSER_H=0; FUSE2.shortcuts=%5B%5D; io=Woa3K79GCWSAJX5lAAAB; _csrf=030eee503681883696abda24067459984c33c77a83dcfc089f9794cd61556790a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22NnkYh61AOEBxYN3KGRS92DSfz3iXlAG1%22%3B%7D; language=bb6ce3163c1f588e67bf425ac15e954b7b2dba33b884af94990c7579c2f94236a%3A2%3A%7Bi%3A0%3Bs%3A8%3A%22language%22%3Bi%3A1%3Bs%3A5%3A%22en-US%22%3B%7D; PHPSESSID=hdc6vq781co4p7mieuqb5a4p63\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'33672\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'GET\'\n    \'QUERY_STRING\' => \'r=installer%2Fconfig%2Ffinished\'\n    \'REQUEST_URI\' => \'/coacting-humhub/index.php?r=installer%2Fconfig%2Ffinished\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590014844.357\n    \'REQUEST_TIME\' => 1590014844\n]'),
(9, 1, 'yii\\base\\ErrorException:32', 1590014938.82, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', 'yii\\base\\ErrorException: Module \'memcached\' already loaded in Unknown:0\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(10, 4, 'application', 1590014938.7725, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', '$_GET = [\n    \'r\' => \'live/poll\'\n    \'last\' => \'1590014919\'\n]\n\n$_SERVER = [\n    \'SCRIPT_URL\' => \'/coacting-humhub/index.php\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/index.php\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'HTTP_ACCEPT\' => \'*/*\'\n    \'HTTP_X_CSRF_TOKEN\' => \'BwwVYC2nVSWI-iUlrLBKY3AoUCayN5BGGOaqxMUgZtJ2Ym8TbN0DfPLNZk7l2ToNEUIId4ti-nF0jOaGvBYuoA==\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_X_REQUESTED_WITH\' => \'XMLHttpRequest\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'cors\'\n    \'HTTP_SEC_FETCH_DEST\' => \'empty\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/index.php?r=dashboard%2Fdashboard\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'HTTP_COOKIE\' => \'has_js=1; _ga=GA1.1.1494242784.1514515536; G_AUTHUSER_H=0; FUSE2.shortcuts=%5B%5D; io=Woa3K79GCWSAJX5lAAAB; language=bb6ce3163c1f588e67bf425ac15e954b7b2dba33b884af94990c7579c2f94236a%3A2%3A%7Bi%3A0%3Bs%3A8%3A%22language%22%3Bi%3A1%3Bs%3A5%3A%22en-US%22%3B%7D; PHPSESSID=1pkig23dm2pcm5irh80327vrt4; _identity=11e4335de1774e2a708669e727f0857f0347f0be5c674ab299841c95896ef409a%3A2%3A%7Bi%3A0%3Bs%3A9%3A%22_identity%22%3Bi%3A1%3Bs%3A50%3A%22%5B1%2C%22a7638a08-35c3-47a6-bb76-d68738799a2f%22%2C2592000%5D%22%3B%7D; _csrf=afae16fd67bc13cdbac26b37f0a888652d7ee81426575362733eb37f3ea52be6a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22qnzsAzVYz7CkIipnajXQ9Uj7ljLBy6Hr%22%3B%7D\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'33886\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'GET\'\n    \'QUERY_STRING\' => \'r=live%2Fpoll&last=1590014919\'\n    \'REQUEST_URI\' => \'/coacting-humhub/index.php?r=live%2Fpoll&last=1590014919\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590014938.763\n    \'REQUEST_TIME\' => 1590014938\n]'),
(11, 1, 'yii\\base\\ErrorException:32', 1590015276.05, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', 'yii\\base\\ErrorException: Module \'memcached\' already loaded in Unknown:0\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(12, 4, 'application', 1590015276.0078, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', '$_GET = [\n    \'r\' => \'live/poll\'\n    \'last\' => \'1590015260\'\n]\n\n$_SERVER = [\n    \'SCRIPT_URL\' => \'/coacting-humhub/index.php\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/index.php\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'HTTP_ACCEPT\' => \'*/*\'\n    \'HTTP_X_CSRF_TOKEN\' => \'lb9sFpUa9dwdueYaaPy9JB64DjlKeXjKH2rZdbjhOxHk0RZl1GCjhWeOpXEhlc1Kf9JWaHMsEv1zAJU3wddzYw==\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_X_REQUESTED_WITH\' => \'XMLHttpRequest\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'cors\'\n    \'HTTP_SEC_FETCH_DEST\' => \'empty\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/index.php?r=dashboard%2Fdashboard\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'HTTP_COOKIE\' => \'has_js=1; _ga=GA1.1.1494242784.1514515536; G_AUTHUSER_H=0; FUSE2.shortcuts=%5B%5D; io=Woa3K79GCWSAJX5lAAAB; language=bb6ce3163c1f588e67bf425ac15e954b7b2dba33b884af94990c7579c2f94236a%3A2%3A%7Bi%3A0%3Bs%3A8%3A%22language%22%3Bi%3A1%3Bs%3A5%3A%22en-US%22%3B%7D; PHPSESSID=1pkig23dm2pcm5irh80327vrt4; _identity=11e4335de1774e2a708669e727f0857f0347f0be5c674ab299841c95896ef409a%3A2%3A%7Bi%3A0%3Bs%3A9%3A%22_identity%22%3Bi%3A1%3Bs%3A50%3A%22%5B1%2C%22a7638a08-35c3-47a6-bb76-d68738799a2f%22%2C2592000%5D%22%3B%7D; _csrf=afae16fd67bc13cdbac26b37f0a888652d7ee81426575362733eb37f3ea52be6a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22qnzsAzVYz7CkIipnajXQ9Uj7ljLBy6Hr%22%3B%7D\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'34046\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'GET\'\n    \'QUERY_STRING\' => \'r=live%2Fpoll&last=1590015260\'\n    \'REQUEST_URI\' => \'/coacting-humhub/index.php?r=live%2Fpoll&last=1590015260\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590015276.001\n    \'REQUEST_TIME\' => 1590015276\n]'),
(13, 1, 'yii\\base\\ErrorException:32', 1590015393.8, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', 'yii\\base\\ErrorException: Module \'memcached\' already loaded in Unknown:0\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(14, 4, 'application', 1590015393.7523, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', '$_GET = [\n    \'last\' => \'1590015376\'\n]\n\n$_SERVER = [\n    \'REDIRECT_SCRIPT_URL\' => \'/coacting-humhub/live/poll\'\n    \'REDIRECT_SCRIPT_URI\' => \'http://localhost/coacting-humhub/live/poll\'\n    \'REDIRECT_BASE\' => \'/coacting-humhub\'\n    \'REDIRECT_STATUS\' => \'200\'\n    \'SCRIPT_URL\' => \'/coacting-humhub/live/poll\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/live/poll\'\n    \'BASE\' => \'/coacting-humhub\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'HTTP_ACCEPT\' => \'*/*\'\n    \'HTTP_X_CSRF_TOKEN\' => \'HVTHqlOXtLNXF5EmVhfdyd4wEZiJuPRz-YrwGtouhodsOr3ZEu3i6i0g0k0ffq2nv1pJybDtnkSV4LxYoxjO9Q==\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_X_REQUESTED_WITH\' => \'XMLHttpRequest\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'cors\'\n    \'HTTP_SEC_FETCH_DEST\' => \'empty\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/dashboard\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'HTTP_COOKIE\' => \'has_js=1; _ga=GA1.1.1494242784.1514515536; G_AUTHUSER_H=0; FUSE2.shortcuts=%5B%5D; io=Woa3K79GCWSAJX5lAAAB; language=bb6ce3163c1f588e67bf425ac15e954b7b2dba33b884af94990c7579c2f94236a%3A2%3A%7Bi%3A0%3Bs%3A8%3A%22language%22%3Bi%3A1%3Bs%3A5%3A%22en-US%22%3B%7D; PHPSESSID=1pkig23dm2pcm5irh80327vrt4; _identity=11e4335de1774e2a708669e727f0857f0347f0be5c674ab299841c95896ef409a%3A2%3A%7Bi%3A0%3Bs%3A9%3A%22_identity%22%3Bi%3A1%3Bs%3A50%3A%22%5B1%2C%22a7638a08-35c3-47a6-bb76-d68738799a2f%22%2C2592000%5D%22%3B%7D; _csrf=afae16fd67bc13cdbac26b37f0a888652d7ee81426575362733eb37f3ea52be6a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22qnzsAzVYz7CkIipnajXQ9Uj7ljLBy6Hr%22%3B%7D\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'34128\'\n    \'REDIRECT_URL\' => \'/coacting-humhub/live/poll\'\n    \'REDIRECT_QUERY_STRING\' => \'last=1590015376\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'GET\'\n    \'QUERY_STRING\' => \'last=1590015376\'\n    \'REQUEST_URI\' => \'/coacting-humhub/live/poll?last=1590015376\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590015393.744\n    \'REQUEST_TIME\' => 1590015393\n]'),
(15, 1, 'yii\\base\\ErrorException:32', 1590015712.7144, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', 'yii\\base\\ErrorException: Module \'memcached\' already loaded in Unknown:0\nStack trace:\n#0 [internal function]: yii\\base\\ErrorHandler->handleFatalError()\n#1 {main}'),
(16, 4, 'application', 1590015712.6677, '[172.18.0.1][1][1pkig23dm2pcm5irh80327vrt4]', '$_GET = [\n    \'last\' => \'1590015695\'\n]\n\n$_SERVER = [\n    \'REDIRECT_SCRIPT_URL\' => \'/coacting-humhub/live/poll\'\n    \'REDIRECT_SCRIPT_URI\' => \'http://localhost/coacting-humhub/live/poll\'\n    \'REDIRECT_BASE\' => \'/coacting-humhub\'\n    \'REDIRECT_STATUS\' => \'200\'\n    \'SCRIPT_URL\' => \'/coacting-humhub/live/poll\'\n    \'SCRIPT_URI\' => \'http://localhost/coacting-humhub/live/poll\'\n    \'BASE\' => \'/coacting-humhub\'\n    \'HTTP_HOST\' => \'localhost\'\n    \'HTTP_CONNECTION\' => \'keep-alive\'\n    \'HTTP_ACCEPT\' => \'*/*\'\n    \'HTTP_X_CSRF_TOKEN\' => \'E5rmPStjJPr4eadG8V1naTshTYW9unlY2jn0JEelG-hi9JxOahlyo4JO5C24NBcHWksV1ITvE2-2U7hmPpNTmg==\'\n    \'HTTP_USER_AGENT\' => \'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_14_6) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/81.0.4044.138 Safari/537.36\'\n    \'HTTP_X_REQUESTED_WITH\' => \'XMLHttpRequest\'\n    \'HTTP_SEC_FETCH_SITE\' => \'same-origin\'\n    \'HTTP_SEC_FETCH_MODE\' => \'cors\'\n    \'HTTP_SEC_FETCH_DEST\' => \'empty\'\n    \'HTTP_REFERER\' => \'http://localhost/coacting-humhub/devtools/index\'\n    \'HTTP_ACCEPT_ENCODING\' => \'gzip, deflate, br\'\n    \'HTTP_ACCEPT_LANGUAGE\' => \'en-US,en;q=0.9\'\n    \'HTTP_COOKIE\' => \'has_js=1; _ga=GA1.1.1494242784.1514515536; G_AUTHUSER_H=0; FUSE2.shortcuts=%5B%5D; io=Woa3K79GCWSAJX5lAAAB; language=bb6ce3163c1f588e67bf425ac15e954b7b2dba33b884af94990c7579c2f94236a%3A2%3A%7Bi%3A0%3Bs%3A8%3A%22language%22%3Bi%3A1%3Bs%3A5%3A%22en-US%22%3B%7D; PHPSESSID=1pkig23dm2pcm5irh80327vrt4; _identity=11e4335de1774e2a708669e727f0857f0347f0be5c674ab299841c95896ef409a%3A2%3A%7Bi%3A0%3Bs%3A9%3A%22_identity%22%3Bi%3A1%3Bs%3A50%3A%22%5B1%2C%22a7638a08-35c3-47a6-bb76-d68738799a2f%22%2C2592000%5D%22%3B%7D; _csrf=afae16fd67bc13cdbac26b37f0a888652d7ee81426575362733eb37f3ea52be6a%3A2%3A%7Bi%3A0%3Bs%3A5%3A%22_csrf%22%3Bi%3A1%3Bs%3A32%3A%22qnzsAzVYz7CkIipnajXQ9Uj7ljLBy6Hr%22%3B%7D\'\n    \'PATH\' => \'/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin\'\n    \'SERVER_SIGNATURE\' => \'<address>Apache/2.4.18 (Ubuntu) Server at localhost Port 80</address>\n\'\n    \'SERVER_SOFTWARE\' => \'Apache/2.4.18 (Ubuntu)\'\n    \'SERVER_NAME\' => \'localhost\'\n    \'SERVER_ADDR\' => \'172.18.0.6\'\n    \'SERVER_PORT\' => \'80\'\n    \'REMOTE_ADDR\' => \'172.18.0.1\'\n    \'DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'REQUEST_SCHEME\' => \'http\'\n    \'CONTEXT_PREFIX\' => \'\'\n    \'CONTEXT_DOCUMENT_ROOT\' => \'/var/www/html\'\n    \'SERVER_ADMIN\' => \'webmaster@localhost\'\n    \'SCRIPT_FILENAME\' => \'/var/www/html/coacting-humhub/index.php\'\n    \'REMOTE_PORT\' => \'34390\'\n    \'REDIRECT_URL\' => \'/coacting-humhub/live/poll\'\n    \'REDIRECT_QUERY_STRING\' => \'last=1590015695\'\n    \'GATEWAY_INTERFACE\' => \'CGI/1.1\'\n    \'SERVER_PROTOCOL\' => \'HTTP/1.1\'\n    \'REQUEST_METHOD\' => \'GET\'\n    \'QUERY_STRING\' => \'last=1590015695\'\n    \'REQUEST_URI\' => \'/coacting-humhub/live/poll?last=1590015695\'\n    \'SCRIPT_NAME\' => \'/coacting-humhub/index.php\'\n    \'PHP_SELF\' => \'/coacting-humhub/index.php\'\n    \'REQUEST_TIME_FLOAT\' => 1590015712.66\n    \'REQUEST_TIME\' => 1590015712\n]');

-- --------------------------------------------------------

--
-- Table structure for table `logging`
--

CREATE TABLE `logging` (
  `id` int(11) NOT NULL,
  `level` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `category` varchar(128) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logtime` int(11) DEFAULT NULL,
  `message` text COLLATE utf8mb4_unicode_ci
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migration`
--

CREATE TABLE `migration` (
  `version` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `apply_time` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migration`
--

INSERT INTO `migration` (`version`, `apply_time`) VALUES
('m000000_000000_base', 1590014769),
('m131023_164513_initial', 1590014770),
('m131023_165411_initial', 1590014770),
('m131023_165625_initial', 1590014770),
('m131023_165755_initial', 1590014770),
('m131023_165835_initial', 1590014770),
('m131023_170033_initial', 1590014770),
('m131023_170135_initial', 1590014770),
('m131023_170159_initial', 1590014770),
('m131023_170253_initial', 1590014770),
('m131023_170339_initial', 1590014770),
('m131203_110444_oembed', 1590014770),
('m131213_165552_user_optimize', 1590014770),
('m140226_111945_ldap', 1590014771),
('m140303_125031_password', 1590014771),
('m140304_142711_memberautoadd', 1590014771),
('m140321_000917_content', 1590014771),
('m140324_170617_membership', 1590014771),
('m140507_150421_create_settings_table', 1590014771),
('m140507_171527_create_settings_table', 1590014771),
('m140512_141414_i18n_profilefields', 1590014771),
('m140513_180317_createlogging', 1590014771),
('m140701_000611_profile_genderfield', 1590014771),
('m140701_074404_protect_default_profilefields', 1590014771),
('m140702_143912_notify_notification_unify', 1590014771),
('m140703_104527_profile_birthdayfield', 1590014771),
('m140704_080659_installationid', 1590014771),
('m140705_065525_emailing_settings', 1590014771),
('m140706_135210_lastlogin', 1590014771),
('m140829_122906_delete', 1590014772),
('m140830_145504_following', 1590014772),
('m140901_080147_indizies', 1590014772),
('m140901_080432_indices', 1590014772),
('m140901_112246_addState', 1590014772),
('m140901_153403_addState', 1590014772),
('m140901_170329_group_create_space', 1590014772),
('m140902_091234_session_key_length', 1590014772),
('m140907_140822_zip_field_to_text', 1590014772),
('m140930_205511_fix_default', 1590014772),
('m140930_205859_fix_default', 1590014772),
('m140930_210142_fix_default', 1590014772),
('m140930_210635_fix_default', 1590014773),
('m140930_212528_fix_default', 1590014773),
('m141015_173305_follow_notifications', 1590014773),
('m141019_093319_mentioning', 1590014773),
('m141020_162639_fix_default', 1590014773),
('m141020_193920_rm_alsocreated', 1590014773),
('m141020_193931_rm_alsoliked', 1590014773),
('m141021_162639_oembed_setting', 1590014773),
('m141022_094635_addDefaults', 1590014773),
('m141106_185632_log_init', 1590014773),
('m150204_103433_html5_notified', 1590014773),
('m150210_190006_user_invite_lang', 1590014773),
('m150302_114347_add_visibility', 1590014773),
('m150322_194403_remove_type_field', 1590014773),
('m150322_195619_allowedExt2Text', 1590014773),
('m150429_223856_optimize', 1590014773),
('m150510_102900_update', 1590014773),
('m150629_220311_change', 1590014774),
('m150703_012735_typelength', 1590014774),
('m150703_024635_activityTypes', 1590014774),
('m150703_033650_namespace', 1590014774),
('m150703_130157_migrate', 1590014774),
('m150704_005338_namespace', 1590014774),
('m150704_005418_namespace', 1590014774),
('m150704_005434_namespace', 1590014774),
('m150704_005452_namespace', 1590014774),
('m150704_005504_namespace', 1590014774),
('m150713_054441_timezone', 1590014774),
('m150714_093525_activity', 1590014774),
('m150714_100355_cleanup', 1590014774),
('m150831_061628_notifications', 1590014774),
('m150910_223305_fix_user_follow', 1590014775),
('m150924_133344_update_notification_fix', 1590014775),
('m150924_154635_user_invite_add_first_lastname', 1590014775),
('m150927_190830_create_contentcontainer', 1590014775),
('m150928_103711_permissions', 1590014775),
('m150928_134934_groups', 1590014775),
('m150928_140718_setColorVariables', 1590014775),
('m151010_124437_group_permissions', 1590014775),
('m151010_175000_default_visibility', 1590014775),
('m151013_223814_include_dashboard', 1590014775),
('m151022_131128_module_fix', 1590014775),
('m151106_090948_addColor', 1590014775),
('m151223_171310_fix_notifications', 1590014775),
('m151226_164234_authclient', 1590014775),
('m160125_053702_stored_filename', 1590014775),
('m160205_203840_foreign_keys', 1590014776),
('m160205_203913_foreign_keys', 1590014776),
('m160205_203939_foreign_keys', 1590014776),
('m160205_203955_foreign_keys', 1590014776),
('m160205_204000_foreign_keys', 1590014776),
('m160205_204010_foreign_keys', 1590014776),
('m160205_205540_foreign_keys', 1590014776),
('m160216_160119_initial', 1590014777),
('m160217_161220_addCanLeaveFlag', 1590014777),
('m160220_013525_contentcontainer_id', 1590014777),
('m160221_222312_public_permission_change', 1590014777),
('m160225_180229_remove_website', 1590014777),
('m160227_073020_birthday_date', 1590014777),
('m160229_162959_multiusergroups', 1590014778),
('m160309_141222_longerUserName', 1590014778),
('m160408_100725_rename_groupadmin_to_manager', 1590014778),
('m160415_180332_wall_remove', 1590014778),
('m160501_220850_activity_pk_int', 1590014778),
('m160507_202611_settings', 1590014778),
('m160508_005740_settings_cleanup', 1590014779),
('m160509_214811_spaceurl', 1590014779),
('m160517_132535_group', 1590014779),
('m160523_105732_profile_searchable', 1590014779),
('m160714_142827_remove_space_id', 1590014779),
('m161031_161947_file_directories', 1590014779),
('m170110_151419_membership_notifications', 1590014779),
('m170110_152425_space_follow_reset_send_notification', 1590014779),
('m170111_190400_disable_web_notifications', 1590014779),
('m170112_115052_settings', 1590014779),
('m170118_162332_streamchannel', 1590014779),
('m170119_160740_initial', 1590014779),
('m170123_125622_pinned', 1590014779),
('m170211_105743_show_in_stream', 1590014780),
('m170224_100937_fix_default_modules', 1590014780),
('m170723_133337_content_tag', 1590014780),
('m170723_133338_content_tag_sort_order', 1590014780),
('m170805_211208_authclient_id', 1590014780),
('m170810_220543_group_sort', 1590014780),
('m171015_155102_contentcontainer_module', 1590014780),
('m171025_142030_queue_update', 1590014780),
('m171025_200312_utf8mb4_fixes', 1590014781),
('m171027_220519_exclusive_jobs', 1590014781),
('m180305_084435_membership_pk', 1590014781),
('m180315_112748_fix_email_length', 1590014781),
('m181029_160453_collation', 1590014783),
('m190211_133045_channel_length', 1590014783),
('m190309_201944_rename_settings', 1590014783),
('m190920_142605_fix_language_codes', 1590014783),
('m200217_122108_profile_translation_fix', 1590014783),
('m200218_122109_profile_translation_fix2', 1590014783),
('m200323_162006_fix_visibility', 1590014783);

-- --------------------------------------------------------

--
-- Table structure for table `module_enabled`
--

CREATE TABLE `module_enabled` (
  `module_id` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `module_enabled`
--

INSERT INTO `module_enabled` (`module_id`) VALUES
('devtools');

-- --------------------------------------------------------

--
-- Table structure for table `notification`
--

CREATE TABLE `notification` (
  `id` int(11) NOT NULL,
  `class` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(11) NOT NULL,
  `seen` tinyint(4) DEFAULT NULL,
  `source_class` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source_pk` int(11) DEFAULT NULL,
  `space_id` int(11) DEFAULT NULL,
  `emailed` tinyint(4) NOT NULL DEFAULT '0',
  `created_at` datetime NOT NULL,
  `desktop_notified` tinyint(1) DEFAULT '0',
  `originator_user_id` int(11) DEFAULT NULL,
  `module` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `group_key` varchar(75) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `send_web_notifications` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `notification`
--

INSERT INTO `notification` (`id`, `class`, `user_id`, `seen`, `source_class`, `source_pk`, `space_id`, `emailed`, `created_at`, `desktop_notified`, `originator_user_id`, `module`, `group_key`, `send_web_notifications`) VALUES
(1, 'humhub\\modules\\comment\\notifications\\NewComment', 1, 0, 'humhub\\modules\\comment\\models\\Comment', 1, 1, 0, '2020-05-20 22:47:23', 1, 2, 'comment', 'humhub\\modules\\post\\models\\Post-2', 1),
(2, 'humhub\\modules\\comment\\notifications\\NewComment', 3, 0, 'humhub\\modules\\comment\\models\\Comment', 1, 1, 0, '2020-05-20 22:47:23', 0, 2, 'comment', 'humhub\\modules\\post\\models\\Post-2', 1),
(3, 'humhub\\modules\\comment\\notifications\\NewComment', 1, 0, 'humhub\\modules\\comment\\models\\Comment', 2, 1, 0, '2020-05-20 22:47:23', 1, 3, 'comment', 'humhub\\modules\\post\\models\\Post-2', 1),
(4, 'humhub\\modules\\comment\\notifications\\NewComment', 2, 0, 'humhub\\modules\\comment\\models\\Comment', 2, 1, 0, '2020-05-20 22:47:23', 0, 3, 'comment', 'humhub\\modules\\post\\models\\Post-2', 1),
(5, 'humhub\\modules\\like\\notifications\\NewLike', 2, 0, 'humhub\\modules\\like\\models\\Like', 1, 1, 0, '2020-05-20 22:47:24', 0, 3, 'like', 'humhub\\modules\\comment\\models\\Comment-1', 1),
(6, 'humhub\\modules\\like\\notifications\\NewLike', 1, 0, 'humhub\\modules\\like\\models\\Like', 2, 1, 0, '2020-05-20 22:47:24', 1, 3, 'like', 'humhub\\modules\\post\\models\\Post-2', 1);

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(11) NOT NULL,
  `message_2trash` text COLLATE utf8mb4_unicode_ci,
  `message` text COLLATE utf8mb4_unicode_ci,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `message_2trash`, `message`, `url`, `created_at`, `created_by`, `updated_at`, `updated_by`) VALUES
(1, NULL, 'Yay! I\'ve just installed HumHub ;Cool;', NULL, '2020-05-20 22:47:19', 1, '2020-05-20 22:47:19', 1),
(2, NULL, 'We\'re looking for great slogans of famous brands. Maybe you can come up with some samples?', NULL, '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1);

-- --------------------------------------------------------

--
-- Table structure for table `profile`
--

CREATE TABLE `profile` (
  `user_id` int(11) NOT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `street` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `zip` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birthday_hide_year` int(1) DEFAULT NULL,
  `birthday` date DEFAULT NULL,
  `about` text COLLATE utf8mb4_unicode_ci,
  `phone_private` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone_work` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fax` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `im_skype` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `im_xmpp` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_facebook` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_linkedin` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_xing` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_youtube` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_vimeo` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_flickr` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_myspace` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `url_twitter` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile`
--

INSERT INTO `profile` (`user_id`, `firstname`, `lastname`, `title`, `gender`, `street`, `zip`, `city`, `country`, `state`, `birthday_hide_year`, `birthday`, `about`, `phone_private`, `phone_work`, `mobile`, `fax`, `im_skype`, `im_xmpp`, `url`, `url_facebook`, `url_linkedin`, `url_xing`, `url_youtube`, `url_vimeo`, `url_flickr`, `url_myspace`, `url_twitter`) VALUES
(1, 'Eldon', 'Marks', 'System Administration', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(2, 'David', 'Roberts', 'Late riser', NULL, '2443 Queens Lane', '24574', 'Allwood', 'Virginia', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL),
(3, 'Sara', 'Schuster', 'Do-gooder', NULL, 'Schmarjestrasse 51', '17095', 'Friedland', 'Niedersachsen', NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `profile_field`
--

CREATE TABLE `profile_field` (
  `id` int(11) NOT NULL,
  `profile_field_category_id` int(11) NOT NULL,
  `module_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `field_type_class` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `field_type_config` text COLLATE utf8mb4_unicode_ci,
  `internal_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `sort_order` int(11) NOT NULL DEFAULT '100',
  `required` tinyint(4) DEFAULT NULL,
  `show_at_registration` tinyint(4) DEFAULT NULL,
  `editable` tinyint(4) NOT NULL DEFAULT '1',
  `visible` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ldap_attribute` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `translation_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` int(1) DEFAULT NULL,
  `searchable` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_field`
--

INSERT INTO `profile_field` (`id`, `profile_field_category_id`, `module_id`, `field_type_class`, `field_type_config`, `internal_name`, `title`, `description`, `sort_order`, `required`, `show_at_registration`, `editable`, `visible`, `created_at`, `created_by`, `updated_at`, `updated_by`, `ldap_attribute`, `translation_category`, `is_system`, `searchable`) VALUES
(1, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":20,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'firstname', 'First name', NULL, 100, 1, 1, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, 'givenName', NULL, 1, 1),
(2, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":30,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'lastname', 'Last name', NULL, 200, 1, 1, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, 'sn', NULL, 1, 1),
(3, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":50,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'title', 'Title', NULL, 300, NULL, NULL, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, 'title', NULL, 1, 1),
(4, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Select', '{\"options\":\"male=>Male\\nfemale=>Female\\ncustom=>Custom\",\"fieldTypes\":[]}', 'gender', 'Gender', NULL, 300, NULL, NULL, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, NULL, 1, 1),
(5, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":150,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'street', 'Street', NULL, 400, NULL, NULL, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, NULL, 1, 1),
(6, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":10,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'zip', 'Zip', NULL, 500, NULL, NULL, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, NULL, 1, 1),
(7, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'city', 'City', NULL, 600, NULL, NULL, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, NULL, 1, 1),
(8, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\CountrySelect', '{\"options\":null,\"fieldTypes\":[]}', 'country', 'Country', NULL, 700, NULL, NULL, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, NULL, 1, 1),
(9, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'state', 'State', NULL, 800, NULL, NULL, 1, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, NULL, 1, 1),
(10, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Birthday', '{\"defaultHideAge\":\"0\",\"fieldTypes\":[]}', 'birthday', 'Birthday', NULL, 900, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(11, 1, NULL, 'humhub\\modules\\user\\models\\fieldtype\\TextArea', '{\"fieldTypes\":[]}', 'about', 'About', NULL, 900, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(12, 2, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'phone_private', 'Phone Private', NULL, 100, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(13, 2, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'phone_work', 'Phone Work', NULL, 200, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(14, 2, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'mobile', 'Mobile', NULL, 300, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(15, 2, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'fax', 'Fax', NULL, 400, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(16, 2, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":100,\"validator\":null,\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'im_skype', 'Skype Nickname', NULL, 500, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(17, 2, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"email\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'im_xmpp', 'XMPP Jabber Address', NULL, 800, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(18, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url', 'Url', NULL, 100, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(19, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_facebook', 'Facebook URL', NULL, 200, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(20, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_linkedin', 'LinkedIn URL', NULL, 300, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(21, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_xing', 'Xing URL', NULL, 400, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(22, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_youtube', 'Youtube URL', NULL, 500, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(23, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_vimeo', 'Vimeo URL', NULL, 600, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(24, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_flickr', 'Flickr URL', NULL, 700, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(25, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_myspace', 'MySpace URL', NULL, 800, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:24', NULL, NULL, NULL, 1, 1),
(26, 3, NULL, 'humhub\\modules\\user\\models\\fieldtype\\Text', '{\"minLength\":null,\"maxLength\":255,\"validator\":\"url\",\"default\":null,\"regexp\":null,\"regexpErrorMessage\":null,\"fieldTypes\":[]}', 'url_twitter', 'Twitter URL', NULL, 1000, NULL, NULL, 1, 1, '2020-05-20 22:46:24', NULL, '2020-05-20 22:46:25', NULL, NULL, NULL, 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `profile_field_category`
--

CREATE TABLE `profile_field_category` (
  `id` int(11) NOT NULL,
  `title` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `sort_order` int(11) NOT NULL DEFAULT '100',
  `module_id` int(11) DEFAULT NULL,
  `visibility` tinyint(4) NOT NULL DEFAULT '1',
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `translation_category` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_system` int(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `profile_field_category`
--

INSERT INTO `profile_field_category` (`id`, `title`, `description`, `sort_order`, `module_id`, `visibility`, `created_at`, `created_by`, `updated_at`, `updated_by`, `translation_category`, `is_system`) VALUES
(1, 'General', '', 100, NULL, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, 1),
(2, 'Communication', '', 200, NULL, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, 1),
(3, 'Social bookmarks', '', 300, NULL, 1, '2020-05-20 22:46:23', NULL, '2020-05-20 22:46:23', NULL, NULL, 1);

-- --------------------------------------------------------

--
-- Table structure for table `queue`
--

CREATE TABLE `queue` (
  `id` int(11) NOT NULL,
  `channel` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job` blob NOT NULL,
  `pushed_at` int(11) NOT NULL,
  `ttr` int(11) NOT NULL,
  `delay` int(11) NOT NULL,
  `priority` int(11) UNSIGNED NOT NULL DEFAULT '1024',
  `reserved_at` int(11) DEFAULT NULL,
  `attempt` int(11) DEFAULT NULL,
  `done_at` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queue`
--

INSERT INTO `queue` (`id`, `channel`, `job`, `pushed_at`, `ttr`, `delay`, `priority`, `reserved_at`, `attempt`, `done_at`) VALUES
(1, 'queue', 0x4f3a34313a2268756d6875625c6d6f64756c65735c7365617263685c6a6f62735c557064617465446f63756d656e74223a323a7b733a31373a226163746976655265636f7264436c617373223b733a33313a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c55736572223b733a31303a227072696d6172794b6579223b693a313b7d, 1590014838, 300, 0, 1024, NULL, NULL, NULL),
(2, 'queue', 0x4f3a34313a2268756d6875625c6d6f64756c65735c7365617263685c6a6f62735c557064617465446f63756d656e74223a323a7b733a31373a226163746976655265636f7264436c617373223b733a33333a2268756d6875625c6d6f64756c65735c73706163655c6d6f64656c735c5370616365223b733a31303a227072696d6172794b6579223b693a313b7d, 1590014839, 300, 0, 1024, NULL, NULL, NULL),
(3, 'queue', 0x4f3a35333a2268756d6875625c6d6f64756c65735c6e6f74696669636174696f6e5c6a6f62735c53656e6442756c6b4e6f74696669636174696f6e223a323a7b733a31323a226e6f74696669636174696f6e223b433a35313a2268756d6875625c6d6f64756c65735c636f6e74656e745c6e6f74696669636174696f6e735c436f6e74656e7443726561746564223a3130383a7b613a333a7b733a31313a22736f75726365436c617373223b733a33313a2268756d6875625c6d6f64756c65735c706f73745c6d6f64656c735c506f7374223b733a383a22736f75726365506b223b693a313b733a31333a226f726967696e61746f725f6964223b693a313b7d7d733a353a227175657279223b4f3a34363a2268756d6875625c6d6f64756c65735c757365725c636f6d706f6e656e74735c416374697665517565727955736572223a33333a7b733a333a2273716c223b4e3b733a323a226f6e223b4e3b733a383a226a6f696e57697468223b613a313a7b693a303b613a333a7b693a303b613a313a7b693a303b733a373a2270726f66696c65223b7d693a313b623a313b693a323b733a393a224c454654204a4f494e223b7d7d733a363a2273656c656374223b4e3b733a31323a2273656c6563744f7074696f6e223b4e3b733a383a2264697374696e6374223b4e3b733a343a2266726f6d223b4e3b733a373a2267726f75704279223b4e3b733a343a226a6f696e223b613a313a7b693a303b613a333a7b693a303b733a393a224c454654204a4f494e223b693a313b733a31363a2273706163655f6d656d62657273686970223b693a323b733a33323a2273706163655f6d656d626572736869702e757365725f69643d757365722e6964223b7d7d733a363a22686176696e67223b4e3b733a353a22756e696f6e223b613a313a7b693a303b613a323a7b733a353a227175657279223b4f3a34363a2268756d6875625c6d6f64756c65735c757365725c636f6d706f6e656e74735c416374697665517565727955736572223a33333a7b733a333a2273716c223b4e3b733a323a226f6e223b4e3b733a383a226a6f696e57697468223b4e3b733a363a2273656c656374223b4e3b733a31323a2273656c6563744f7074696f6e223b4e3b733a383a2264697374696e6374223b4e3b733a343a2266726f6d223b4e3b733a373a2267726f75704279223b4e3b733a343a226a6f696e223b4e3b733a363a22686176696e67223b4e3b733a353a22756e696f6e223b4e3b733a31313a227769746851756572696573223b4e3b733a363a22706172616d73223b613a303a7b7d733a31383a22717565727943616368654475726174696f6e223b4e3b733a32303a2271756572794361636865446570656e64656e6379223b4e3b733a32373a22007969695c626173655c436f6d706f6e656e74005f6576656e7473223b613a303a7b7d733a33353a22007969695c626173655c436f6d706f6e656e74005f6576656e7457696c646361726473223b613a303a7b7d733a33303a22007969695c626173655c436f6d706f6e656e74005f6265686176696f7273223b613a303a7b7d733a353a227768657265223b613a333a7b693a303b733a333a22616e64223b693a313b613a313a7b733a31313a22757365722e737461747573223b693a313b7d693a323b613a323a7b693a303b733a363a22657869737473223b693a313b4f3a31383a227969695c64625c4163746976655175657279223a33333a7b733a333a2273716c223b4e3b733a323a226f6e223b4e3b733a383a226a6f696e57697468223b4e3b733a363a2273656c656374223b4e3b733a31323a2273656c6563744f7074696f6e223b4e3b733a383a2264697374696e6374223b4e3b733a343a2266726f6d223b4e3b733a373a2267726f75704279223b4e3b733a343a226a6f696e223b4e3b733a363a22686176696e67223b4e3b733a353a22756e696f6e223b4e3b733a31313a227769746851756572696573223b4e3b733a363a22706172616d73223b613a303a7b7d733a31383a22717565727943616368654475726174696f6e223b4e3b733a32303a2271756572794361636865446570656e64656e6379223b4e3b733a32373a22007969695c626173655c436f6d706f6e656e74005f6576656e7473223b613a303a7b7d733a33353a22007969695c626173655c436f6d706f6e656e74005f6576656e7457696c646361726473223b613a303a7b7d733a33303a22007969695c626173655c436f6d706f6e656e74005f6265686176696f7273223b613a303a7b7d733a353a227768657265223b613a343a7b693a303b733a333a22616e64223b693a313b613a323a7b733a32343a22757365725f666f6c6c6f772e6f626a6563745f6d6f64656c223b733a33333a2268756d6875625c6d6f64756c65735c73706163655c6d6f64656c735c5370616365223b733a32313a22757365725f666f6c6c6f772e6f626a6563745f6964223b693a313b7d693a323b733a32373a22757365725f666f6c6c6f772e757365725f69643d757365722e6964223b693a333b613a313a7b733a33303a22757365725f666f6c6c6f772e73656e645f6e6f74696669636174696f6e73223b693a313b7d7d733a353a226c696d6974223b4e3b733a363a226f6666736574223b4e3b733a373a226f726465724279223b4e3b733a373a22696e6465784279223b4e3b733a31363a22656d756c617465457865637574696f6e223b623a303b733a31303a226d6f64656c436c617373223b733a33333a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c466f6c6c6f77223b733a343a2277697468223b4e3b733a373a2261734172726179223b4e3b733a383a226d756c7469706c65223b4e3b733a31323a227072696d6172794d6f64656c223b4e3b733a343a226c696e6b223b4e3b733a333a22766961223b4e3b733a393a22696e76657273654f66223b4e3b733a32363a22007969695c64625c4163746976655175657279007669614d6170223b4e3b7d7d7d733a353a226c696d6974223b4e3b733a363a226f6666736574223b4e3b733a373a226f726465724279223b4e3b733a373a22696e6465784279223b4e3b733a31363a22656d756c617465457865637574696f6e223b623a303b733a31303a226d6f64656c436c617373223b733a33313a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c55736572223b733a343a2277697468223b4e3b733a373a2261734172726179223b4e3b733a383a226d756c7469706c65223b4e3b733a31323a227072696d6172794d6f64656c223b4e3b733a343a226c696e6b223b4e3b733a333a22766961223b4e3b733a393a22696e76657273654f66223b4e3b733a32363a22007969695c64625c4163746976655175657279007669614d6170223b4e3b7d733a333a22616c6c223b623a303b7d7d733a31313a227769746851756572696573223b4e3b733a363a22706172616d73223b613a303a7b7d733a31383a22717565727943616368654475726174696f6e223b4e3b733a32303a2271756572794361636865446570656e64656e6379223b4e3b733a32373a22007969695c626173655c436f6d706f6e656e74005f6576656e7473223b613a303a7b7d733a33353a22007969695c626173655c436f6d706f6e656e74005f6576656e7457696c646361726473223b613a303a7b7d733a33303a22007969695c626173655c436f6d706f6e656e74005f6265686176696f7273223b613a303a7b7d733a353a227768657265223b613a353a7b693a303b733a333a22616e64223b693a313b613a313a7b733a31313a22757365722e737461747573223b693a313b7d693a323b613a313a7b733a32333a2273706163655f6d656d626572736869702e737461747573223b693a333b7d693a333b613a313a7b733a33353a2273706163655f6d656d626572736869702e73656e645f6e6f74696669636174696f6e73223b693a313b7d693a343b613a313a7b733a383a2273706163655f6964223b693a313b7d7d733a353a226c696d6974223b4e3b733a363a226f6666736574223b4e3b733a373a226f726465724279223b613a313a7b733a31363a2270726f66696c652e6c6173746e616d65223b693a343b7d733a373a22696e6465784279223b4e3b733a31363a22656d756c617465457865637574696f6e223b623a303b733a31303a226d6f64656c436c617373223b733a33313a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c55736572223b733a343a2277697468223b4e3b733a373a2261734172726179223b4e3b733a383a226d756c7469706c65223b4e3b733a31323a227072696d6172794d6f64656c223b4e3b733a343a226c696e6b223b4e3b733a333a22766961223b4e3b733a393a22696e76657273654f66223b4e3b733a32363a22007969695c64625c4163746976655175657279007669614d6170223b4e3b7d7d, 1590014839, 300, 0, 1024, NULL, NULL, NULL),
(4, 'queue', 0x4f3a34313a2268756d6875625c6d6f64756c65735c7365617263685c6a6f62735c557064617465446f63756d656e74223a323a7b733a31373a226163746976655265636f7264436c617373223b733a33313a2268756d6875625c6d6f64756c65735c706f73745c6d6f64656c735c506f7374223b733a31303a227072696d6172794b6579223b693a313b7d, 1590014839, 300, 0, 1024, NULL, NULL, NULL),
(5, 'queue', 0x4f3a34313a2268756d6875625c6d6f64756c65735c7365617263685c6a6f62735c557064617465446f63756d656e74223a323a7b733a31373a226163746976655265636f7264436c617373223b733a33313a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c55736572223b733a31303a227072696d6172794b6579223b693a323b7d, 1590014842, 300, 0, 1024, NULL, NULL, NULL),
(6, 'queue', 0x4f3a34393a2268756d6875625c6d6f64756c65735c6e6f74696669636174696f6e5c6a6f62735c53656e644e6f74696669636174696f6e223a323a7b733a31323a226e6f74696669636174696f6e223b433a35393a2268756d6875625c6d6f64756c65735c61646d696e5c6e6f74696669636174696f6e735c496e636c75646547726f75704e6f74696669636174696f6e223a3130393a7b613a333a7b733a31313a22736f75726365436c617373223b733a33323a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c47726f7570223b733a383a22736f75726365506b223b693a323b733a31333a226f726967696e61746f725f6964223b693a313b7d7d733a31313a22726563697069656e744964223b693a323b7d, 1590014842, 300, 0, 1024, NULL, NULL, NULL),
(7, 'queue', 0x4f3a34313a2268756d6875625c6d6f64756c65735c7365617263685c6a6f62735c557064617465446f63756d656e74223a323a7b733a31373a226163746976655265636f7264436c617373223b733a33313a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c55736572223b733a31303a227072696d6172794b6579223b693a333b7d, 1590014842, 300, 0, 1024, NULL, NULL, NULL),
(8, 'queue', 0x4f3a34393a2268756d6875625c6d6f64756c65735c6e6f74696669636174696f6e5c6a6f62735c53656e644e6f74696669636174696f6e223a323a7b733a31323a226e6f74696669636174696f6e223b433a35393a2268756d6875625c6d6f64756c65735c61646d696e5c6e6f74696669636174696f6e735c496e636c75646547726f75704e6f74696669636174696f6e223a3130393a7b613a333a7b733a31313a22736f75726365436c617373223b733a33323a2268756d6875625c6d6f64756c65735c757365725c6d6f64656c735c47726f7570223b733a383a22736f75726365506b223b693a323b733a31333a226f726967696e61746f725f6964223b693a313b7d7d733a31313a22726563697069656e744964223b693a333b7d, 1590014842, 300, 0, 1024, NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `queue_exclusive`
--

CREATE TABLE `queue_exclusive` (
  `id` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `job_message_id` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `job_status` smallint(6) DEFAULT '2',
  `last_update` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `queue_exclusive`
--

INSERT INTO `queue_exclusive` (`id`, `job_message_id`, `job_status`, `last_update`) VALUES
('search.update.34adc3f8ba09ff3ef48513a09d9518f3', '6', 2, '2020-05-20 22:47:22'),
('search.update.3d7b2424b991a0e9e3f987185369465f', '2', 2, '2020-05-20 22:47:19'),
('search.update.5a1f359fd1047743f8abb8379d515399', '7', 2, '2020-05-20 22:47:22'),
('search.update.a4cb70bb5efe4d31fd8302088ec03b1d', '1', 2, '2020-05-20 22:47:18'),
('search.update.bf655d283ff597c58a52647d65148919', '5', 2, '2020-05-20 22:47:22'),
('search.update.d44770b89ae8b7a54ccc3fb8b952c372', '4', 2, '2020-05-20 22:47:19');

-- --------------------------------------------------------

--
-- Table structure for table `setting`
--

CREATE TABLE `setting` (
  `id` int(11) NOT NULL,
  `name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci,
  `module_id` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `setting`
--

INSERT INTO `setting` (`id`, `name`, `value`, `module_id`) VALUES
(1, 'oembedProviders', '{\"vimeo.com\":\"http:\\/\\/vimeo.com\\/api\\/oembed.json?scheme=https&url=%url%&format=json&maxwidth=450\",\"youtube.com\":\"http:\\/\\/www.youtube.com\\/oembed?scheme=https&url=%url%&format=json&maxwidth=450\",\"youtu.be\":\"http:\\/\\/www.youtube.com\\/oembed?scheme=https&url=%url%&format=json&maxwidth=450\",\"soundcloud.com\":\"https:\\/\\/soundcloud.com\\/oembed?url=%url%&format=json&maxwidth=450\",\"slideshare.net\":\"https:\\/\\/www.slideshare.net\\/api\\/oembed\\/2?url=%url%&format=json&maxwidth=450\"}', 'base'),
(2, 'defaultVisibility', '1', 'space'),
(3, 'defaultJoinPolicy', '1', 'space'),
(4, 'themeParents', '[]', 'base'),
(5, 'name', 'CoActing.org', 'base'),
(6, 'baseUrl', 'http://localhost/coacting-humhub', 'base'),
(7, 'paginationSize', '10', 'base'),
(8, 'displayNameFormat', '{profile.firstname} {profile.lastname}', 'base'),
(9, 'horImageScrollOnMobile', '1', 'base'),
(10, 'cronLastDailyRun', '1590014783', 'base'),
(11, 'auth.needApproval', '0', 'user'),
(12, 'auth.anonymousRegistration', '1', 'user'),
(13, 'auth.internalUsersCanInvite', '1', 'user'),
(14, 'auth.showCaptureInRegisterForm', '1', 'user'),
(15, 'mailer.transportType', 'php', 'base'),
(16, 'mailer.systemEmailAddress', 'social@example.com', 'base'),
(17, 'mailer.systemEmailName', 'CoActing.org', 'base'),
(18, 'mailSummaryInterval', '2', 'activity'),
(19, 'maxFileSize', '5242880', 'file'),
(20, 'maxPreviewImageWidth', '200', 'file'),
(21, 'maxPreviewImageHeight', '200', 'file'),
(22, 'hideImageFileInfo', '0', 'file'),
(23, 'cache.class', 'yii\\caching\\FileCache', 'base'),
(24, 'cache.expireTime', '3600', 'base'),
(25, 'installationId', '4206d83a91d1b9107a938266d5ed472a', 'admin'),
(26, 'spaceOrder', '0', 'space'),
(27, 'enable', '1', 'tour'),
(28, 'defaultLanguage', 'en-US', 'base'),
(29, 'enable_html5_desktop_notifications', '0', 'notification'),
(30, 'cronLastRun', '1590014783', 'base'),
(31, 'theme.var.HumHub.default', '#ededed', 'base'),
(32, 'theme.var.HumHub.primary', '#708fa0', 'base'),
(33, 'theme.var.HumHub.info', '#6fdbe8', 'base'),
(34, 'theme.var.HumHub.success', '#97d271', 'base'),
(35, 'theme.var.HumHub.warning', '#fdd198', 'base'),
(36, 'theme.var.HumHub.danger', '#ff8989', 'base'),
(37, 'theme.var.HumHub.text-color-main', '#777', 'base'),
(38, 'theme.var.HumHub.text-color-secondary', '#7a7a7a', 'base'),
(39, 'theme.var.HumHub.text-color-highlight', '#555', 'base'),
(40, 'theme.var.HumHub.text-color-soft', '#bebebe', 'base'),
(41, 'theme.var.HumHub.text-color-soft2', '#aeaeae', 'base'),
(42, 'theme.var.HumHub.text-color-soft3', '#bac2c7', 'base'),
(43, 'theme.var.HumHub.text-color-contrast', '#fff', 'base'),
(44, 'theme.var.HumHub.background-color-main', '#fff', 'base'),
(45, 'theme.var.HumHub.background-color-secondary', '#f7f7f7', 'base'),
(46, 'theme.var.HumHub.background-color-page', '#ededed', 'base'),
(47, 'theme.var.HumHub.background-color-highlight', '#fff8e0', 'base'),
(48, 'theme.var.HumHub.background3', '#d7d7d7', 'base'),
(49, 'theme.var.HumHub.background4', '#b2b2b2', 'base'),
(50, 'theme.var.HumHub.background-color-success', '#f7fbf4', 'base'),
(51, 'theme.var.HumHub.text-color-success', '#84be5e', 'base'),
(52, 'theme.var.HumHub.border-color-success', '#97d271', 'base'),
(53, 'theme.var.HumHub.background-color-warning', '#fffbf7', 'base'),
(54, 'theme.var.HumHub.text-color-warning', '#e9b168', 'base'),
(55, 'theme.var.HumHub.border-color-warning', '#fdd198', 'base'),
(56, 'theme.var.HumHub.background-color-danger', '#fff6f6', 'base'),
(57, 'theme.var.HumHub.text-color-danger', ' #ff8989', 'base'),
(58, 'theme.var.HumHub.border-color-danger', '#ff8989', 'base'),
(59, 'theme.var.HumHub.mail-font-url', '\'http://fonts.googleapis.com/css?family=Open+Sans:300,100,400,600\'', 'base'),
(60, 'theme.var.HumHub.mail-font-family', '\'Open Sans\',Arial,Tahoma,Helvetica,sans-serif', 'base'),
(61, 'useCase', 'other', 'base'),
(62, 'sampleData', '1', 'installer'),
(63, 'secret', '13ae9691-75dc-40cf-9605-a99e7a922d14', 'base'),
(64, 'timeZone', 'UTC', 'base'),
(65, 'group.adminGroupId', '1', 'user');

-- --------------------------------------------------------

--
-- Table structure for table `space`
--

CREATE TABLE `space` (
  `id` int(11) NOT NULL,
  `guid` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(45) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `join_policy` tinyint(4) DEFAULT NULL,
  `visibility` tinyint(4) DEFAULT NULL,
  `status` tinyint(4) NOT NULL DEFAULT '1',
  `tags` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `ldap_dn` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_add_new_members` int(4) DEFAULT NULL,
  `contentcontainer_id` int(11) DEFAULT NULL,
  `default_content_visibility` tinyint(1) DEFAULT NULL,
  `color` varchar(7) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `members_can_leave` int(11) DEFAULT '1',
  `url` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `space`
--

INSERT INTO `space` (`id`, `guid`, `name`, `description`, `join_policy`, `visibility`, `status`, `tags`, `created_at`, `created_by`, `updated_at`, `updated_by`, `ldap_dn`, `auto_add_new_members`, `contentcontainer_id`, `default_content_visibility`, `color`, `members_can_leave`, `url`) VALUES
(1, '8f4545a9-fdf8-4a80-841d-7ae150820de4', 'Welcome Space', 'Your first sample space to discover the platform.', 2, 2, 1, NULL, '2020-05-20 22:47:19', 1, '2020-05-20 22:47:19', 1, NULL, 1, 2, NULL, '#6fdbe8', 1, 'welcome-space');

-- --------------------------------------------------------

--
-- Table structure for table `space_membership`
--

CREATE TABLE `space_membership` (
  `space_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `originator_user_id` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `request_message` text COLLATE utf8mb4_unicode_ci,
  `last_visit` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `group_id` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT 'member',
  `show_at_dashboard` tinyint(1) DEFAULT '1',
  `can_cancel_membership` int(11) DEFAULT '1',
  `send_notifications` tinyint(1) DEFAULT '0',
  `id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `space_membership`
--

INSERT INTO `space_membership` (`space_id`, `user_id`, `originator_user_id`, `status`, `request_message`, `last_visit`, `created_at`, `created_by`, `updated_at`, `updated_by`, `group_id`, `show_at_dashboard`, `can_cancel_membership`, `send_notifications`, `id`) VALUES
(1, 1, NULL, 3, NULL, '2020-05-20 23:02:15', '2020-05-20 22:47:19', 1, '2020-05-20 22:47:19', 1, 'admin', 1, 1, 0, 1),
(1, 2, NULL, 3, NULL, NULL, '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1, 'member', 1, 1, 0, 2),
(1, 3, NULL, 3, NULL, NULL, '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1, 'member', 1, 1, 0, 3);

-- --------------------------------------------------------

--
-- Table structure for table `url_oembed`
--

CREATE TABLE `url_oembed` (
  `url` varchar(180) COLLATE utf8mb4_unicode_ci NOT NULL,
  `preview` text COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `guid` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` char(150) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auth_mode` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tags` text COLLATE utf8mb4_unicode_ci,
  `language` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `last_login` datetime DEFAULT NULL,
  `visibility` int(1) DEFAULT '1',
  `time_zone` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contentcontainer_id` int(11) DEFAULT NULL,
  `authclient_id` varchar(60) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `guid`, `status`, `username`, `email`, `auth_mode`, `tags`, `language`, `created_at`, `created_by`, `updated_at`, `updated_by`, `last_login`, `visibility`, `time_zone`, `contentcontainer_id`, `authclient_id`) VALUES
(1, 'a7638a08-35c3-47a6-bb76-d68738799a2f', 1, 'administrator', 'eldon.marks@gmail.com', 'local', 'Administration, Support, HumHub', '', '2020-05-20 22:47:18', NULL, '2020-05-20 22:47:18', NULL, '2020-05-20 22:47:32', 1, NULL, 1, NULL),
(2, '0a6c2ff1-aa0d-4e04-b98e-e086b454d5c8', 1, 'david1986', 'david.roberts@example.com', 'local', 'Microsoft Office, Marketing, SEM, Digital Native', '', '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1, NULL, 1, NULL, 3, NULL),
(3, '16daae3f-fa9b-4be6-b4f9-17efae15804d', 1, 'sara1989', 'sara.schuster@example.com', 'local', 'Yoga, Travel, English, German, French', '', '2020-05-20 22:47:22', 1, '2020-05-20 22:47:22', 1, NULL, 1, NULL, 4, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `user_auth`
--

CREATE TABLE `user_auth` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `source` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source_id` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_follow`
--

CREATE TABLE `user_follow` (
  `id` int(11) NOT NULL,
  `object_model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `send_notifications` tinyint(1) DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_follow`
--

INSERT INTO `user_follow` (`id`, `object_model`, `object_id`, `user_id`, `send_notifications`) VALUES
(1, 'humhub\\modules\\post\\models\\Post', 1, 1, 1),
(2, 'humhub\\modules\\post\\models\\Post', 2, 1, 1),
(3, 'humhub\\modules\\post\\models\\Post', 2, 2, 1),
(4, 'humhub\\modules\\post\\models\\Post', 2, 3, 1);

-- --------------------------------------------------------

--
-- Table structure for table `user_friendship`
--

CREATE TABLE `user_friendship` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `friend_user_id` int(11) NOT NULL,
  `created_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_http_session`
--

CREATE TABLE `user_http_session` (
  `id` char(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire` int(11) DEFAULT NULL,
  `user_id` int(11) DEFAULT NULL,
  `data` longblob
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_http_session`
--

INSERT INTO `user_http_session` (`id`, `expire`, `user_id`, `data`) VALUES
('1pkig23dm2pcm5irh80327vrt4', 1621551777, 1, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b5f5f72657475726e55726c7c733a36363a22687474703a2f2f6c6f63616c686f73742f636f616374696e672d68756d6875622f696e6465782e7068703f723d64617368626f61726425324664617368626f617264223b5f5f636170746368612f757365722f617574682f636170746368617c733a363a226a7277757667223b5f5f636170746368612f757365722f617574682f63617074636861636f756e747c693a313b5f5f69647c693a313b5f5f6578706972657c693a313539303031373137373b63757272656e7441757468436c69656e7449647c733a353a226c6f63616c223b757365722e63616e53656541646d696e53656374696f6e7c623a313b6c6976652e706f6c6c2e6c617374517565727954696d657c693a313539303031353737373b),
('6hp4ca678rtgt311gotvfii7l6', 1621550847, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('6thj7qql8hvei2369lg1o3vum6', 1621551564, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('7v7b023gqkb6s58paikvu6bnf5', 1621551378, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('8lnvfr0ju11qt426tqjc8mqe42', 1621551628, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('99tg6rshnv8brh6ena5efm65q1', 1621550849, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('dcrgch0nb59b3tion153mkto92', 1621551539, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('nvbjn8bclgvj26i0n46fv69ag3', 1621551245, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('p7md8o71l0037dlmhp38sa2d96', 1621551632, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('pcpkqnosg2s2qlmju1mqusn3j7', 1621550854, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('piecqdmv7cb76eja4o4u37cbi2', 1621551632, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('qkt7fjngj3hlct2aq1kjgksl31', 1621551609, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b),
('umf5b1ptpunv4d4ejn931fk766', 1621551630, NULL, 0x5f5f666c6173687c613a303a7b7d73656375726974792d7363726970742d7372632d6e6f6e63657c4e3b);

-- --------------------------------------------------------

--
-- Table structure for table `user_invite`
--

CREATE TABLE `user_invite` (
  `id` int(11) NOT NULL,
  `user_originator_id` int(11) DEFAULT NULL,
  `space_invite_id` int(11) DEFAULT NULL,
  `email` char(150) COLLATE utf8mb4_unicode_ci NOT NULL,
  `source` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `token` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  `updated_by` int(11) DEFAULT NULL,
  `language` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `firstname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lastname` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_mentioning`
--

CREATE TABLE `user_mentioning` (
  `id` int(11) NOT NULL,
  `object_model` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `object_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `user_password`
--

CREATE TABLE `user_password` (
  `id` int(11) NOT NULL,
  `user_id` int(10) DEFAULT NULL,
  `algorithm` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` text COLLATE utf8mb4_unicode_ci,
  `salt` text COLLATE utf8mb4_unicode_ci,
  `created_at` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `user_password`
--

INSERT INTO `user_password` (`id`, `user_id`, `algorithm`, `password`, `salt`, `created_at`) VALUES
(1, 1, 'sha512whirlpool', '8494509034a0d0323ff85745fce4120769e6bd3e1d7d357c86883d72e242b383ca8e87a74d30e580665441c2d90e8574826d62702b855303a7ad6888830434b4', '98f6617f-dcb8-4f45-96cd-c954467f94a7', '2020-05-20 22:47:18');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `activity`
--
ALTER TABLE `activity`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `comment`
--
ALTER TABLE `comment`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_comment-created_by` (`created_by`);

--
-- Indexes for table `content`
--
ALTER TABLE `content`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `index_object_model` (`object_model`,`object_id`),
  ADD UNIQUE KEY `index_guid` (`guid`),
  ADD KEY `fk-contentcontainer` (`contentcontainer_id`),
  ADD KEY `fk-create-user` (`created_by`),
  ADD KEY `fk-update-user` (`updated_by`),
  ADD KEY `stream_channe` (`stream_channel`);

--
-- Indexes for table `contentcontainer`
--
ALTER TABLE `contentcontainer`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_guid` (`guid`),
  ADD UNIQUE KEY `unique_target` (`class`,`pk`);

--
-- Indexes for table `contentcontainer_module`
--
ALTER TABLE `contentcontainer_module`
  ADD PRIMARY KEY (`contentcontainer_id`,`module_id`);

--
-- Indexes for table `contentcontainer_permission`
--
ALTER TABLE `contentcontainer_permission`
  ADD PRIMARY KEY (`permission_id`,`group_id`,`module_id`,`contentcontainer_id`);

--
-- Indexes for table `contentcontainer_setting`
--
ALTER TABLE `contentcontainer_setting`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings-unique` (`module_id`,`contentcontainer_id`,`name`),
  ADD KEY `fk-contentcontainerx` (`contentcontainer_id`);

--
-- Indexes for table `content_tag`
--
ALTER TABLE `content_tag`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx-content-tag` (`module_id`,`contentcontainer_id`,`name`),
  ADD KEY `fk-content-tag-container-id` (`contentcontainer_id`),
  ADD KEY `fk-content-tag-parent-id` (`parent_id`);

--
-- Indexes for table `content_tag_relation`
--
ALTER TABLE `content_tag_relation`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk-content-tag-rel-content-id` (`content_id`),
  ADD KEY `fk-content-tag-rel-tag-id` (`tag_id`);

--
-- Indexes for table `file`
--
ALTER TABLE `file`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_object` (`object_model`,`object_id`),
  ADD KEY `fk_file-created_by` (`created_by`);

--
-- Indexes for table `group`
--
ALTER TABLE `group`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_group-space_id` (`space_id`);

--
-- Indexes for table `group_permission`
--
ALTER TABLE `group_permission`
  ADD PRIMARY KEY (`permission_id`,`group_id`,`module_id`),
  ADD KEY `fk_group_permission-group_id` (`group_id`);

--
-- Indexes for table `group_user`
--
ALTER TABLE `group_user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx-group_user` (`user_id`,`group_id`),
  ADD KEY `fk-group-group` (`group_id`);

--
-- Indexes for table `like`
--
ALTER TABLE `like`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_object` (`object_model`,`object_id`),
  ADD KEY `fk_like-created_by` (`created_by`),
  ADD KEY `fk_like-target_user_id` (`target_user_id`);

--
-- Indexes for table `live`
--
ALTER TABLE `live`
  ADD PRIMARY KEY (`id`),
  ADD KEY `contentcontainer` (`contentcontainer_id`);

--
-- Indexes for table `log`
--
ALTER TABLE `log`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_log_level` (`level`),
  ADD KEY `idx_log_category` (`category`);

--
-- Indexes for table `logging`
--
ALTER TABLE `logging`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `migration`
--
ALTER TABLE `migration`
  ADD PRIMARY KEY (`version`);

--
-- Indexes for table `module_enabled`
--
ALTER TABLE `module_enabled`
  ADD PRIMARY KEY (`module_id`);

--
-- Indexes for table `notification`
--
ALTER TABLE `notification`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_user_id` (`user_id`),
  ADD KEY `index_seen` (`seen`),
  ADD KEY `index_desktop_notified` (`desktop_notified`),
  ADD KEY `index_desktop_emailed` (`emailed`),
  ADD KEY `index_groupuser` (`user_id`,`class`,`group_key`);

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `profile`
--
ALTER TABLE `profile`
  ADD PRIMARY KEY (`user_id`);

--
-- Indexes for table `profile_field`
--
ALTER TABLE `profile_field`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_profile_field_category` (`profile_field_category_id`);

--
-- Indexes for table `profile_field_category`
--
ALTER TABLE `profile_field_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `queue`
--
ALTER TABLE `queue`
  ADD PRIMARY KEY (`id`),
  ADD KEY `channel` (`channel`),
  ADD KEY `reserved_at` (`reserved_at`),
  ADD KEY `priority` (`priority`);

--
-- Indexes for table `queue_exclusive`
--
ALTER TABLE `queue_exclusive`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `setting`
--
ALTER TABLE `setting`
  ADD PRIMARY KEY (`id`),
  ADD KEY `unique-setting` (`name`,`module_id`);

--
-- Indexes for table `space`
--
ALTER TABLE `space`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `url-unique` (`url`);

--
-- Indexes for table `space_membership`
--
ALTER TABLE `space_membership`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_status` (`status`),
  ADD KEY `fk_space_membership-space_id` (`space_id`),
  ADD KEY `fk_space_membership-user_id` (`user_id`);

--
-- Indexes for table `url_oembed`
--
ALTER TABLE `url_oembed`
  ADD PRIMARY KEY (`url`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_email` (`email`),
  ADD UNIQUE KEY `unique_username` (`username`),
  ADD UNIQUE KEY `unique_guid` (`guid`),
  ADD UNIQUE KEY `unique_authclient_id` (`authclient_id`);

--
-- Indexes for table `user_auth`
--
ALTER TABLE `user_auth`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_id` (`user_id`);

--
-- Indexes for table `user_follow`
--
ALTER TABLE `user_follow`
  ADD PRIMARY KEY (`id`),
  ADD KEY `index_user` (`user_id`),
  ADD KEY `index_object` (`object_model`,`object_id`);

--
-- Indexes for table `user_friendship`
--
ALTER TABLE `user_friendship`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `idx-friends` (`user_id`,`friend_user_id`),
  ADD KEY `fk-friend` (`friend_user_id`);

--
-- Indexes for table `user_http_session`
--
ALTER TABLE `user_http_session`
  ADD PRIMARY KEY (`id`),
  ADD KEY `fk_user_http_session-user_id` (`user_id`);

--
-- Indexes for table `user_invite`
--
ALTER TABLE `user_invite`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `unique_email` (`email`),
  ADD UNIQUE KEY `unique_token` (`token`);

--
-- Indexes for table `user_mentioning`
--
ALTER TABLE `user_mentioning`
  ADD PRIMARY KEY (`id`),
  ADD KEY `i_user` (`user_id`),
  ADD KEY `i_object` (`object_model`,`object_id`);

--
-- Indexes for table `user_password`
--
ALTER TABLE `user_password`
  ADD PRIMARY KEY (`id`),
  ADD KEY `idx_user_id` (`user_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `activity`
--
ALTER TABLE `activity`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `comment`
--
ALTER TABLE `comment`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `content`
--
ALTER TABLE `content`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `contentcontainer`
--
ALTER TABLE `contentcontainer`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `contentcontainer_setting`
--
ALTER TABLE `contentcontainer_setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `content_tag`
--
ALTER TABLE `content_tag`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `content_tag_relation`
--
ALTER TABLE `content_tag_relation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `file`
--
ALTER TABLE `file`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `group`
--
ALTER TABLE `group`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `group_user`
--
ALTER TABLE `group_user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `like`
--
ALTER TABLE `like`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `live`
--
ALTER TABLE `live`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `log`
--
ALTER TABLE `log`
  MODIFY `id` bigint(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `logging`
--
ALTER TABLE `logging`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `notification`
--
ALTER TABLE `notification`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `profile_field`
--
ALTER TABLE `profile_field`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;

--
-- AUTO_INCREMENT for table `profile_field_category`
--
ALTER TABLE `profile_field_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `queue`
--
ALTER TABLE `queue`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `setting`
--
ALTER TABLE `setting`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=66;

--
-- AUTO_INCREMENT for table `space`
--
ALTER TABLE `space`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `space_membership`
--
ALTER TABLE `space_membership`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `user_auth`
--
ALTER TABLE `user_auth`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_follow`
--
ALTER TABLE `user_follow`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user_friendship`
--
ALTER TABLE `user_friendship`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_invite`
--
ALTER TABLE `user_invite`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_mentioning`
--
ALTER TABLE `user_mentioning`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `user_password`
--
ALTER TABLE `user_password`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `comment`
--
ALTER TABLE `comment`
  ADD CONSTRAINT `fk_comment-created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content`
--
ALTER TABLE `content`
  ADD CONSTRAINT `fk-contentcontainer` FOREIGN KEY (`contentcontainer_id`) REFERENCES `contentcontainer` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk-create-user` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE SET NULL,
  ADD CONSTRAINT `fk-update-user` FOREIGN KEY (`updated_by`) REFERENCES `user` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `contentcontainer_module`
--
ALTER TABLE `contentcontainer_module`
  ADD CONSTRAINT `fk_contentcontainer` FOREIGN KEY (`contentcontainer_id`) REFERENCES `contentcontainer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `contentcontainer_setting`
--
ALTER TABLE `contentcontainer_setting`
  ADD CONSTRAINT `fk-contentcontainerx` FOREIGN KEY (`contentcontainer_id`) REFERENCES `contentcontainer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `content_tag`
--
ALTER TABLE `content_tag`
  ADD CONSTRAINT `fk-content-tag-container-id` FOREIGN KEY (`contentcontainer_id`) REFERENCES `contentcontainer` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-content-tag-parent-id` FOREIGN KEY (`parent_id`) REFERENCES `content_tag` (`id`) ON DELETE SET NULL;

--
-- Constraints for table `content_tag_relation`
--
ALTER TABLE `content_tag_relation`
  ADD CONSTRAINT `fk-content-tag-rel-content-id` FOREIGN KEY (`content_id`) REFERENCES `content` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-content-tag-rel-tag-id` FOREIGN KEY (`tag_id`) REFERENCES `content_tag` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `file`
--
ALTER TABLE `file`
  ADD CONSTRAINT `fk_file-created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `group`
--
ALTER TABLE `group`
  ADD CONSTRAINT `fk_group-space_id` FOREIGN KEY (`space_id`) REFERENCES `space` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `group_permission`
--
ALTER TABLE `group_permission`
  ADD CONSTRAINT `fk_group_permission-group_id` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `group_user`
--
ALTER TABLE `group_user`
  ADD CONSTRAINT `fk-group-group` FOREIGN KEY (`group_id`) REFERENCES `group` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-user-group` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `like`
--
ALTER TABLE `like`
  ADD CONSTRAINT `fk_like-created_by` FOREIGN KEY (`created_by`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_like-target_user_id` FOREIGN KEY (`target_user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `live`
--
ALTER TABLE `live`
  ADD CONSTRAINT `contentcontainer` FOREIGN KEY (`contentcontainer_id`) REFERENCES `contentcontainer` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `notification`
--
ALTER TABLE `notification`
  ADD CONSTRAINT `fk_notification-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile`
--
ALTER TABLE `profile`
  ADD CONSTRAINT `fk_profile-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `profile_field`
--
ALTER TABLE `profile_field`
  ADD CONSTRAINT `fk_profile_field-profile_field_category_id` FOREIGN KEY (`profile_field_category_id`) REFERENCES `profile_field_category` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `space_membership`
--
ALTER TABLE `space_membership`
  ADD CONSTRAINT `fk_space_membership-space_id` FOREIGN KEY (`space_id`) REFERENCES `space` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `fk_space_membership-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_auth`
--
ALTER TABLE `user_auth`
  ADD CONSTRAINT `fk_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_follow`
--
ALTER TABLE `user_follow`
  ADD CONSTRAINT `fk_user_follow-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_friendship`
--
ALTER TABLE `user_friendship`
  ADD CONSTRAINT `fk-friend` FOREIGN KEY (`friend_user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `fk-user` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE;

--
-- Constraints for table `user_http_session`
--
ALTER TABLE `user_http_session`
  ADD CONSTRAINT `fk_user_http_session-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_mentioning`
--
ALTER TABLE `user_mentioning`
  ADD CONSTRAINT `fk_user_mentioning-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

--
-- Constraints for table `user_password`
--
ALTER TABLE `user_password`
  ADD CONSTRAINT `fk_user_password-user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
